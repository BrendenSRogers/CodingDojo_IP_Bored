from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, UserManager, readListItem, watchListItem, listenListItem
import bcrypt

# Create your views here.

def index(request):
    return redirect('/main')

def main(request):
    return render(request, "main.html")

def register(request):
    if request.method == "POST":
        errors = User.objects.registration_validator(request.POST)
        if len(errors) != 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/main')
        else:
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            new_user = User.objects.create(first_name = request.POST['first_name'], last_name = request.POST['last_name'], email = request.POST['email'], password=pw_hash)
            request.session['user_id'] = new_user.id
            return redirect ('/myList')
    return redirect('/')

def login(request):
    if request.method == "POST":
        users_with_email = User.objects.filter(email=request.POST['email'])
        if users_with_email:
            user = users_with_email[0]
            if bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
                request.session['user_id'] = user.id
                return redirect('/myList')
        messages.error(request, "Email or password are not correct.")
    return redirect('/')

def myList(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    this_user = User.objects.filter(id = request.session['user_id'])
    return render(request, "myList.html")

def logout(request):
    request.session.flush()
    return redirect('/main')

def addRead(request):
    return render(request, "addRead.html")

def newRead(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    if request.method == "POST":
        user = User.objects.get(id=request.session['user_id'])
        newRead = readListItem.objects.create(item_name = request.POST['title'], item_url = request.POST['url'])
    return redirect('/myList/read')

def read(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    this_user = User.objects.filter(id = request.session['user_id'])
    context = {
        'user': this_user[0],
        'all_read': readListItem.objects.all(),
    }    
    return render(request, "read.html", context)

def addWatch(request):
    return render(request, "addWatch.html")

def newWatch(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    if request.method == "POST":
        user = User.objects.get(id=request.session['user_id'])
        newWatch = watchListItem.objects.create(item_name = request.POST['title'], item_url = request.POST['url'])
    return redirect('/myList/watch')

def watch(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    this_user = User.objects.filter(id = request.session['user_id'])
    context = {
        'user': this_user[0],
        'all_watch': watchListItem.objects.all(),
    }    
    return render(request, "watch.html", context)

def addListen(request):
    return render(request, "addListen.html")

def newListen(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    if request.method == "POST":
        user = User.objects.get(id=request.session['user_id'])
        newListen = listenListItem.objects.create(item_name = request.POST['title'], item_url = request.POST['url'])
    return redirect('/myList/listen')

def listen(request):
    if 'user_id' not in request.session:
        return redirect('/main')
    this_user = User.objects.filter(id = request.session['user_id'])
    context = {
        'user': this_user[0],
        'all_listen': listenListItem.objects.all(),
    }    
    return render(request, "listen.html", context)

# def org_detail(request, organization_id):
#     one_org = Organization.objects.get(id=organization_id)
#     this_user = User.objects.filter(id = request.session['user_id'])
#     context = {
#         'user': this_user[0],
#         'organization': one_org
#     }
#     return render(request, 'org_details.html', context)

# def join(request, organization_id):
#     if 'user_id' not in request.session:
#         return redirect('/')
#     if request.method == "POST":
#         one_organization = Organization.objects.get(id=organization_id)
#         this_user = User.objects.get(id=request.session["user_id"])
#         one_organization.members.add(this_user)
#     return redirect(f'/myList/{organization_id}')

# def leave(request, organization_id):
#     if 'user_id' not in request.session:
#         return redirect('/')
#     if request.method == "POST":
#         one_organization = Organization.objects.get(id=organization_id)
#         this_user = User.objects.get(id=request.session["user_id"])
#         one_organization.members.remove(this_user)
#     return redirect('/myList')

# def delete(request, organization_id):
#     if 'user_id' not in request.session:
#         return redirect('/')
#     if request.method == "POST":
#         to_delete = Organization.objects.get(id=organization_id)
#         to_delete.delete()
#     return redirect('/myList')