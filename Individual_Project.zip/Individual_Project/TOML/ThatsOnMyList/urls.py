from django.urls import path
from . import views

urlpatterns = [
    #no address, redirect to main
    path('', views.index),
    #main page
    path('main', views.main),
    #register a User
    path('register', views.register),
    #login as a User
    path('login', views.login),
    #User Dashboard
    path('myList', views.myList),
    #logout a User
    path('logout', views.logout),
    #landing pages for creating a new item
    path('myList/addRead', views.addRead),
    path('myList/addWatch', views.addWatch),
    path('myList/addListen', views.addListen),
    #process of creating a new item
    path('myList/newRead', views.newRead),
    path('myList/newWatch', views.newWatch),
    path('myList/newListen', views.newListen),
    #View a user's lists
    path('myList/read', views.read),
    path('myList/watch', views.watch),
    path('myList/listen', views.listen),
]