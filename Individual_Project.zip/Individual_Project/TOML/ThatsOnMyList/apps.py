from django.apps import AppConfig


class ThatsonmylistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ThatsOnMyList'
