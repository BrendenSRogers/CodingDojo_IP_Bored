from django.db import models
import re
import bcrypt

# Create your models here.

#USERS

class UserManager(models.Manager):
    def registration_validator(self, postData):
        errors = {}
        #validate length of first name
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name must be at least two characters in length."
        #validate length of last name
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name must be at least two characters in length."
        #make sure email is entered and matches format
        email_regex = re.compile(r'^[a-zA-z0-9.+_-]+@[a-zA-z0-9.+_-]+\.[a-zA-Z]+$')
        if len(postData['email'])==0:
            errors['email'] = "You must enter a valid email address."
        elif not email_regex.match(postData['email']):
            errors['email'] = "Email entered must be a valid email address."
        #make sure email is unique
        existing_user = User.objects.filter(email = postData['email'])
        if len(existing_user) > 0:
            errors['duplicate'] = "That email is already in use."
        #make sure password is entered
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters long"
        return errors
    def login_validator(self, postData):
        errors = {}
        # existing_user = User.objects.filter(email = postData['email'])
        #confirm email is entered
        if len(postData['login_email']) == 0:
            errors['login_email'] = "You must enter an email."
        #confirm password is entered
        if len(postData['login_password']) < 8:
            errors['login_password'] = "You must enter a valid password."
        # elif bcrypt.checkpw(postData['password'].endcode(), existing_user[0].password.encode()) != True:
        #     errors['password'] = "Email and password do not match."
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = UserManager()

###LIST ITEMS

class readListItem(models.Model):
    item_name = models.CharField(max_length=255)
    item_url = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)

class watchListItem(models.Model):
    item_name = models.CharField(max_length=255)
    item_url = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)

class listenListItem(models.Model):
    item_name = models.CharField(max_length=255)
    item_url = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)